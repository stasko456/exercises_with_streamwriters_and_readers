﻿using System.ComponentModel;
using System.Net.Http.Headers;

namespace project_29
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ex 1:
            //using (StreamReader reader = new StreamReader("Program.cs"))
            //{
            //    int lineNumber = 0;
            //    string line = reader.ReadLine();
            //    while (line != null)
            //    {
            //        lineNumber++;
            //        Console.WriteLine($"Line {lineNumber}: {line}");
            //        line = reader.ReadLine();
            //    }
            //}

            // ex 2:
            //using (StreamReader reader = new StreamReader("Program.cs"))
            //{
            //    using (StreamWriter writer = new StreamWriter("reversed.txt"))
            //    {
            //        string line = reader.ReadLine();
            //        while (line != null)
            //        {
            //            for (int i = line.Length - 1; i >= 0; i--)
            //            {
            //                writer.Write(line[i]);
            //            }
            //            writer.WriteLine(line);
            //            line = reader.ReadLine();
            //        }
            //    }
            //}

            // ex 3:
            //using (StreamReader reader = new StreamReader("file.txt"))
            //{
            //    int lineNumber = 0;
            //    string line = reader.ReadLine();
            //    while (line != null)
            //    {
            //        lineNumber++;
            //        if (lineNumber % 2 != 0)
            //        {
            //            Console.WriteLine(line);
            //        }
            //        line = reader.ReadLine();
            //    }
            //}

            // ex 4:
            //using (StreamReader reader = new StreamReader("file.txt"))
            //{
            //    using (StreamWriter writer = new StreamWriter("output.txt"))
            //    {
            //        int lineNumber = 0;
            //        string line = reader.ReadLine();
            //        while (line != null)
            //        {
            //            lineNumber++;
            //            writer.WriteLine($"Line {lineNumber}: {line}");
            //            line = reader.ReadLine();
            //        }
            //    }
            //}

            // ex 5:
            //using (StreamReader wordReader = new StreamReader("words.txt"))
            //{
            //    int count = 0;
            //    string word = wordReader.ReadLine();
            //    while (word != null)
            //    {
            //        using (StreamReader reader = new StreamReader("file.txt"))
            //        {
            //            string line = reader.ReadLine();
            //            while (line != null)
            //            {
            //                string[] text = line.Split(' ').ToArray();
            //                for (int i = 0; i < text.Length; i++)
            //                {
            //                    if (text[i].ToLower().Equals(word))
            //                    {
            //                        count++;
            //                        using (StreamWriter writer = new StreamWriter("result.txt"))
            //                        {
            //                            writer.WriteLine($"{text[i]} - {count}");
            //                        }
            //                    }
            //                }
            //                line = reader.ReadLine();
            //            }
            //        }
            //        word = wordReader.ReadLine();
            //        count = 0;
            //    }
            //}   не работи и не знам как да я направя
        }
    }
}
